package com.example.shamuscernyinventoryapp;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class PermissionActivity extends AppCompatActivity {

    private final ActivityResultLauncher<String> storagePermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                updatePermissionBackground(findViewById(R.id.storagePerm), granted);
            });

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                updatePermissionBackground(findViewById(R.id.smsPerm), granted);
            });

    private void updatePermissionBackground(LinearLayout layout, boolean granted){
        int drawableRes = granted ? R.drawable.custom_permission_card_accepted : R.drawable.custom_permission_card_denied;
        layout.setBackgroundResource(drawableRes);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allow_permissions);

        LinearLayout storagePermArea = findViewById(R.id.storagePerm);
        LinearLayout smsPermArea = findViewById(R.id.smsPerm);
        Button acceptButton = findViewById(R.id.acceptPermsButton);

        storagePermArea.setOnClickListener(v -> {
            //Request storage permissions
            storagePermissionLauncher.launch(PermissionUtils.getMediaPermission(this));
        });

        smsPermArea.setOnClickListener(v -> {
            // Request sms permissions
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        });

        acceptButton.setOnClickListener(v -> {
            startActivity(new Intent(this, InventoryActivity.class));
            finish();
        });
    }
}

