package com.example.shamuscernyinventoryapp;

import android.provider.BaseColumns;

public class InventoryContract {
    private InventoryContract(){}
    public static class InventoryEntry implements BaseColumns{
        public static final String TABLE_NAME = "inventory";
        public static final String COLUMN_ITEM_NAME = "item_name";
        public static final String COLUMN_QUANTITY = "quantity";
        public static final String COLUMN_IMAGE_PATH = "image_path";
    }
}
