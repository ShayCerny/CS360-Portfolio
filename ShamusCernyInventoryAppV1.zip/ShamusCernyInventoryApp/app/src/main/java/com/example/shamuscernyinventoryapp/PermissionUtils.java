package com.example.shamuscernyinventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.content.ContextCompat;

public class PermissionUtils {
    public static boolean hasRequiredPermissions(Context context){
        boolean sms = ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        boolean images = ContextCompat.checkSelfPermission(context, getMediaPermission(context)) == PackageManager.PERMISSION_GRANTED;

        return sms && images;
    }

    public static String getMediaPermission(Context context){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            //can use READ_MEDIA_IMAGES
            return Manifest.permission.READ_MEDIA_IMAGES;
        }else {
            // can use READ_EXTERNAL_STORAGE
            return Manifest.permission.READ_EXTERNAL_STORAGE;
        }
    }

}
