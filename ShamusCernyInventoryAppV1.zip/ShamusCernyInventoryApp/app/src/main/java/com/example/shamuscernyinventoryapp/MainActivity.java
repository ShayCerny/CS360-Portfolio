package com.example.shamuscernyinventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity{

    private EditText emailText;
    private EditText passwordText;
    private Button loginButton;
    private Button signUpButton;

    private boolean emailValid = false;
    private boolean passwordValid = false;

    private AppDatabaseHelper dbHelper;

    private void enableButtons(boolean evalid, boolean pValid){
        if (evalid && pValid){
            signUpButton.setEnabled(true);
            loginButton.setEnabled(true);
        }else{
            signUpButton.setEnabled(false);
            loginButton.setEnabled(false);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailText = findViewById(R.id.editTextEmailAddress);
        passwordText = findViewById(R.id.editTextPassword);
        loginButton = findViewById(R.id.buttonLogin);
        signUpButton = findViewById(R.id.buttonSignUp);

        dbHelper = new AppDatabaseHelper(this);

        emailText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                boolean valid = !s.toString().trim().isEmpty();
                emailValid = valid;
                enableButtons(valid, passwordValid);
            }
        });


        passwordText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                boolean valid = !s.toString().trim().isEmpty();
                passwordValid = valid;
                enableButtons(emailValid, valid);
            }
        });

        loginButton.setOnClickListener(this::Login);

        signUpButton.setOnClickListener(this::SignUp);
    }

    private void openInventoryScreen(){
        Intent intent = new Intent(this, InventoryActivity.class);
        startActivity(intent);
        finish(); // so the user cant go back to login without logging out
    }

    private void openPermissionScreen(){
        Intent intent = new Intent(this, PermissionActivity.class);
        startActivity(intent);
        finish(); // so the user cant go back to login without logging out
    }


    private void Login(View view){
        String email = emailText.getText().toString().trim();
        String password = passwordText.getText().toString().trim();

        if(dbHelper.validateLogin(email,password)){
            if(PermissionUtils.hasRequiredPermissions(this)){
                openInventoryScreen();
            }else{
                openPermissionScreen();
            }

        }else{
            Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
        }
    }

    private void SignUp(View view){
        String email = emailText.getText().toString().trim();
        String password = passwordText.getText().toString().trim();

        boolean success = dbHelper.insertUser(email,password);

        if (success){
            if(PermissionUtils.hasRequiredPermissions(this)){
                openInventoryScreen();
            }else{
                openPermissionScreen();
            }
        }else{
            Toast.makeText(MainActivity.this, "Email already exists", Toast.LENGTH_SHORT).show();
        }
    }
}
