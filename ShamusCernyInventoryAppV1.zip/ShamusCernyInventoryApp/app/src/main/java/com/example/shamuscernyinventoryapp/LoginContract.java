package com.example.shamuscernyinventoryapp;

import android.provider.BaseColumns;

public class LoginContract {
    private LoginContract(){}

    public static class LoginEntry implements BaseColumns{
        public static final String TABLE_NAME = "login";
        public static final String COLUMN_EMAIL = "email";
        public static final String COLUMN_PASSWORD = "password";
    }
}
