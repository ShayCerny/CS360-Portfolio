package com.example.shamuscernyinventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import org.w3c.dom.Text;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class InventoryAdapter extends BaseAdapter {
    private Context context;
    private List<InventoryItem> itemList;
    private AppDatabaseHelper dbHelper;

    public InventoryAdapter(Context context, List<InventoryItem> itemList, AppDatabaseHelper dbHelper){
        this.context = context;
        this.itemList = itemList;
        this.dbHelper = dbHelper;
    }

    @Override
    public int getCount(){return itemList.size();}

    @Override
    public Object getItem(int position){return itemList.get(position);}

    @Override
    public long getItemId(int position){return itemList.get(position).getId();}

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        if(convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.item_inventory,parent,false);
        }

        InventoryItem item = itemList.get(position);

        ImageView itemImage = convertView.findViewById(R.id.itemImage);
        TextView itemName = convertView.findViewById(R.id.itemName);
        TextView itemQty = convertView.findViewById(R.id.itemQuantity);
        ImageButton btnIncrease = convertView.findViewById(R.id.itemBtnIncrease);
        ImageButton btnDecrease = convertView.findViewById(R.id.itemBtnDecrease);
        View stockIndicator = convertView.findViewById(R.id.stockIndicator);

        itemName.setText(item.getName());

        int quantity = item.getQuantity();

        itemQty.setText(String.valueOf(quantity));
        setStockIndicatorColor(stockIndicator, quantity);

        //Load image if path exists
        if(item.getImagePath() != null && !item.getImagePath().isEmpty() && ContextCompat.checkSelfPermission(context, PermissionUtils.getMediaPermission(context)) == PackageManager.PERMISSION_GRANTED){
            try {
                Uri uri = Uri.parse(item.getImagePath());

                // Open input stream via ContentResolver instead of MediaStore.getBitmap()
                InputStream inputStream = context.getContentResolver().openInputStream(uri);
                if (inputStream != null) {
                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                    inputStream.close();
                    itemImage.setImageBitmap(bitmap);
                } else {
                    // If the URI can't be opened, fall back to placeholder
                    itemImage.setImageResource(R.drawable.ic_placeholder_view);
                }
            } catch (IOException e) {
                e.printStackTrace();
                itemImage.setImageResource(R.drawable.ic_placeholder_view);
            }
        }else{
            itemImage.setImageResource(R.drawable.ic_placeholder_view);
        }

        btnIncrease.setOnClickListener(v->adjustQuantity(item, stockIndicator, itemQty, 1));

        btnDecrease.setOnClickListener(v -> adjustQuantity(item, stockIndicator, itemQty, -1));

        return convertView;
    }

    private void adjustQuantity(InventoryItem item, View indicator, TextView itemQty, int amount){
        int currentQty = item.getQuantity();
        if(currentQty == 0 && amount == -1) return;
        currentQty += amount;
        item.setQuantity(currentQty);
        setStockIndicatorColor(indicator, currentQty);
        SMSUtils.handleQuantitySMS(context, item.getName(), currentQty);
        itemQty.setText(String.valueOf(currentQty));
        dbHelper.updateItemQuantity(item.getId(),currentQty);
    }

    private void setStockIndicatorColor(View indicator, int qty){
        if (qty == 0) {
            indicator.setBackgroundTintList(
                    ContextCompat.getColorStateList(context, R.color.danger_red)
            );
        } else if (qty < 10) {
            indicator.setBackgroundTintList(
                    ContextCompat.getColorStateList(context, R.color.yellow)
            );
        } else {
            indicator.setBackgroundTintList(
                    ContextCompat.getColorStateList(context, R.color.green)
            );
        }
    }

    public void setItems(List<InventoryItem> items) {
        this.itemList = items;
    }

}
