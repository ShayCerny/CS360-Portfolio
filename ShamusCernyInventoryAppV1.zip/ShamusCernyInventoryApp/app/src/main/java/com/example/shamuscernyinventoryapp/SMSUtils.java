package com.example.shamuscernyinventoryapp;

import android.content.Context;
import android.telephony.SmsManager;
import android.widget.Toast;


public class SMSUtils {
    public static void handleQuantitySMS(Context context, String itemName, int currentQty) {
        if (currentQty == 10 || currentQty <= 5) {

            SmsManager smsManager = SmsManager.getDefault();

            String message = itemName + " Stock is low, currenyly: " + currentQty;

            if (PermissionUtils.hasRequiredPermissions(context)) {
                try {
                    smsManager.sendTextMessage("9193940802", null, message, null, null);
                    Toast.makeText(context, "SMS sent", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(context, "SMS Failed", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }

            }
        }

    }
}