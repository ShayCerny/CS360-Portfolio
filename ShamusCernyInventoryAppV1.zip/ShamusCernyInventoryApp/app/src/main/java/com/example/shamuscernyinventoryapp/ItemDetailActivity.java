package com.example.shamuscernyinventoryapp;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class ItemDetailActivity extends AppCompatActivity {

    private static final int REQUEST_IMAGE_PICK = 1001;

    private AppDatabaseHelper dbHelper;
    private InventoryItem currentItem;
    private int itemId = -1; // -1 means new item

    private ImageView itemImage;
    private EditText itemName;
    private EditText itemQty;
    private ImageButton increaseButton;
    private ImageButton decreaseButton;
    private Button saveButton;
    private Button deleteButton;

    private Uri selectedImageUri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        dbHelper = new AppDatabaseHelper(this);

        itemImage = findViewById(R.id.itemDetailImage);
        itemName = findViewById(R.id.itemDetailName);
        itemQty = findViewById(R.id.itemDetailQuantity);
        increaseButton = findViewById(R.id.itemDetailIncrease);
        decreaseButton = findViewById(R.id.itemDetailDecrease);
        saveButton = findViewById(R.id.itemDetailSave);
        deleteButton = findViewById(R.id.itemDetailDelete);

        // Check if editing existing item
        Intent intent = getIntent();
        if (intent.hasExtra("itemId")){
            itemId = intent.getIntExtra("itemId",-1);
            if (itemId != -1){
                currentItem = dbHelper.getItemById(itemId);
                if (currentItem != null){
                    loadItem(currentItem);
                }
            }
        }else{
            currentItem = new InventoryItem();
            deleteButton.setEnabled(false); // cant delete if new
        }

        increaseButton.setOnClickListener(v -> {
            int qty = currentItem.getQuantity();
            qty++;
            itemQty.setText(String.valueOf(qty));
            currentItem.setQuantity(qty);
        });

        decreaseButton.setOnClickListener(v -> {
            int qty = currentItem.getQuantity();
            if(qty == 0) return;
            qty--;
            SMSUtils.handleQuantitySMS(this, currentItem.getName(), qty);
            itemQty.setText(String.valueOf(qty));
            currentItem.setQuantity(qty);
        });

        saveButton.setOnClickListener(v -> saveItem());

        deleteButton.setOnClickListener(v -> deleteItem());

        itemName.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                currentItem.setName(String.valueOf(s));
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
        });

        itemQty.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                currentItem.setQuantity(Integer.parseInt(String.valueOf(s)));
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }
        });

        itemImage.setOnClickListener(v -> selectImage());
    }

    private void loadItem(InventoryItem item){
        itemName.setText(item.getName());
        itemQty.setText(String.valueOf(item.getQuantity()));
        if(item.getImagePath() != null && ContextCompat.checkSelfPermission(this, PermissionUtils.getMediaPermission(this)) == PackageManager.PERMISSION_GRANTED) {
            selectedImageUri = Uri.parse(item.getImagePath());
            try {
                InputStream inputStream = getContentResolver().openInputStream(selectedImageUri);
                if (inputStream != null) {
                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                    inputStream.close();
                    itemImage.setImageBitmap(bitmap);
                } else {
                    // Could not open URI, fallback
                    itemImage.setImageResource(R.drawable.ic_placeholder_view);
                }
            } catch (IOException e) {
                e.printStackTrace();
                itemImage.setImageResource(R.drawable.ic_placeholder_view);
            }
        }
    }

    private void saveItem(){
        if (currentItem.getName().isBlank()){
            Toast.makeText(this,"Please Enter an item name", Toast.LENGTH_SHORT).show();
            return;
        }

        if (currentItem.getId() == -1){
            long id = dbHelper.insertInventoryItem(currentItem);
            if (id != -1){
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
            }
        } else{
            int result = dbHelper.updateItem(currentItem);
            if (result > 0){
                Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
            }
        }
        finish();

    }
    private void deleteItem(){
        if(currentItem.getId() != -1){
            int result = dbHelper.deleteItem(currentItem.getId());
            if (result > 0){
                Toast.makeText(this,"Item deleted", Toast.LENGTH_SHORT).show();
            }
            finish();
        }
    }

    private void selectImage(){
        if(ContextCompat.checkSelfPermission(this, PermissionUtils.getMediaPermission(this)) == PackageManager.PERMISSION_GRANTED) {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, REQUEST_IMAGE_PICK);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode,resultCode,data);

        if(resultCode == ItemDetailActivity.RESULT_OK && data != null){
            if (requestCode == REQUEST_IMAGE_PICK) {
                selectedImageUri = data.getData();

                try{
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(),selectedImageUri);
                    itemImage.setImageBitmap(bitmap);
                    currentItem.setImagePath(selectedImageUri);
                } catch (IOException e){
                    Toast.makeText(this, "Failed to load image",Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}
