package com.example.shamuscernyinventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private GridView gridView;
    private InventoryAdapter adapter;
    private List<InventoryItem> items;
    private AppDatabaseHelper dbHelper;
    private Button btnAddItem;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        btnAddItem = findViewById(R.id.btnAddItem);
        dbHelper = new AppDatabaseHelper(this);
        gridView = findViewById(R.id.inventoryGrid);

        loadItemsFromDatabase();

        adapter = new InventoryAdapter(this, items, dbHelper);
        gridView.setAdapter(adapter);

        btnAddItem.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, ItemDetailActivity.class);
            // no item ID means creating new item
            startActivity(intent);
        });

        gridView.setOnItemClickListener((parent,view,position,id)->{
            InventoryItem item = items.get(position);

            Intent intent = new Intent(InventoryActivity.this, ItemDetailActivity.class);
            intent.putExtra("itemId", item.getId()); // pass the database ID
            startActivity(intent);
        });
    }

    private void loadItemsFromDatabase(){
        items = dbHelper.getAllInventoryItems();
    }

    @Override
    protected void onResume(){
        super.onResume();
        //Refresh the GridView
        items = dbHelper.getAllInventoryItems();
        adapter.setItems(items);
        adapter.notifyDataSetChanged();
    }
}
