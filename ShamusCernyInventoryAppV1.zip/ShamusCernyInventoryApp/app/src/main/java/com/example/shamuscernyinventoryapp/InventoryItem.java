package com.example.shamuscernyinventoryapp;

import android.net.Uri;

public class InventoryItem {
    private int id;
    private String name;
    private int quantity;
    private String imagePath; // file path

    public InventoryItem(int id, String name, int quantity, String imagePath){
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.imagePath = imagePath;
    }

    public InventoryItem() {
        this.id = -1;
        this.quantity = 0;
    }

    public int getId(){return id;}
    public String getName(){return name;}
    public int getQuantity(){return quantity;}
    public String getImagePath(){return imagePath;}
    public void setQuantity(int quantity){
        this.quantity = quantity;
    }

    public void setName(String s) {
        this.name = s;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setImagePath(Uri selectedImageUri) {
        this.imagePath = String.valueOf(selectedImageUri);
    }
}
