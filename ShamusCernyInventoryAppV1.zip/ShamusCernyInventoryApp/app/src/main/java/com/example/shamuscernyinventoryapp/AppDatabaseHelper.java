package com.example.shamuscernyinventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class AppDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "app_data.db";
    private static final int DATABASE_VERSION = 1;

    public AppDatabaseHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String SQL_CREATE_LOGIN_TABLE =
                "CREATE TABLE " + LoginContract.LoginEntry.TABLE_NAME + " (" +
                        LoginContract.LoginEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        LoginContract.LoginEntry.COLUMN_EMAIL + " TEXT NOT NULL UNIQUE, " +
                        LoginContract.LoginEntry.COLUMN_PASSWORD + " TEXT NOT NULL);";

        String SQL_CREATE_INVENTORY_TABLE =
                "CREATE TABLE " + InventoryContract.InventoryEntry.TABLE_NAME + " (" +
                        InventoryContract.InventoryEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
                        InventoryContract.InventoryEntry.COLUMN_ITEM_NAME + " TEXT NOT NULL, "+
                        InventoryContract.InventoryEntry.COLUMN_QUANTITY + " INTEGER NOT NULL, "+
                        InventoryContract.InventoryEntry.COLUMN_IMAGE_PATH + " TEXT);";


        db.execSQL(SQL_CREATE_LOGIN_TABLE);
        db.execSQL(SQL_CREATE_INVENTORY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + LoginContract.LoginEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + InventoryContract.InventoryEntry.TABLE_NAME);
        onCreate(db);
    }

    public boolean validateLogin(String email, String password){
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                LoginContract.LoginEntry.TABLE_NAME,
                new String[]{LoginContract.LoginEntry._ID}, // Check if row exists
                LoginContract.LoginEntry.COLUMN_EMAIL + " = ? AND " +
                        LoginContract.LoginEntry.COLUMN_PASSWORD + " = ?",
                new String[]{email,password},
                null,
                null,
                null
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean insertUser(String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if the user already exists
        Cursor cursor = db.query(
                LoginContract.LoginEntry.TABLE_NAME,
                new String[]{LoginContract.LoginEntry._ID},
                LoginContract.LoginEntry.COLUMN_EMAIL + " = ?",
                new String[]{email},
                null,
                null,
                null
        );

        if (cursor.getCount() > 0){
            cursor.close();
            return false; // email exists
        }
        cursor.close();

        // insert new user
        ContentValues values = new ContentValues();
        values.put(LoginContract.LoginEntry.COLUMN_EMAIL, email);
        values.put(LoginContract.LoginEntry.COLUMN_PASSWORD, password);

        long result = db.insert(LoginContract.LoginEntry.TABLE_NAME, null, values);
        return  result != -1; // success if result is -1
    }

    public void updateItemQuantity(int itemId, int newQuantity){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryContract.InventoryEntry.COLUMN_QUANTITY, newQuantity);

        db.update(InventoryContract.InventoryEntry.TABLE_NAME,
                values,
                InventoryContract.InventoryEntry._ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );
    }

    public long insertInventoryItem(InventoryItem item){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryContract.InventoryEntry.COLUMN_ITEM_NAME, item.getName());
        values.put(InventoryContract.InventoryEntry.COLUMN_QUANTITY, item.getQuantity());
        values.put(InventoryContract.InventoryEntry.COLUMN_IMAGE_PATH, item.getImagePath());
        long id = db.insert(InventoryContract.InventoryEntry.TABLE_NAME,null,values);
        item.setId((int)id);
        return id;
    }

    public int updateItem(InventoryItem item){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryContract.InventoryEntry.COLUMN_ITEM_NAME, item.getName());
        values.put(InventoryContract.InventoryEntry.COLUMN_QUANTITY, item.getQuantity());
        values.put(InventoryContract.InventoryEntry.COLUMN_IMAGE_PATH, item.getImagePath());
        return db.update(InventoryContract.InventoryEntry.TABLE_NAME,values,
                InventoryContract.InventoryEntry._ID + "= ?",
                new String[]{String.valueOf(item.getId())});
    }

    public int deleteItem(int Id){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(InventoryContract.InventoryEntry.TABLE_NAME,
                InventoryContract.InventoryEntry._ID + "=?",
                new String[]{String.valueOf(Id)});
    }

    public InventoryItem getItemById(int Id){
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                InventoryContract.InventoryEntry.TABLE_NAME,
                null,
                InventoryContract.InventoryEntry._ID + " = ?",
                new String[]{String.valueOf(Id)},
                null,
                null,
                null
        );
        InventoryItem item = null;

        if (cursor.moveToFirst()){
            String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryContract.InventoryEntry.COLUMN_ITEM_NAME));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryContract.InventoryEntry.COLUMN_QUANTITY));
            String imagePath = cursor.getString(cursor.getColumnIndexOrThrow(InventoryContract.InventoryEntry.COLUMN_IMAGE_PATH));

            item = new InventoryItem(Id, name, quantity,imagePath);
            cursor.close();
        }
        return item;
    }

    public List<InventoryItem> getAllInventoryItems(){
        List<InventoryItem> items= new ArrayList<>();

        //query inventory table
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                InventoryContract.InventoryEntry.TABLE_NAME,
                null,null,null,null,null,null
        );

        while(cursor.moveToNext()){
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryContract.InventoryEntry._ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryContract.InventoryEntry.COLUMN_ITEM_NAME));
            int qty = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryContract.InventoryEntry.COLUMN_QUANTITY));
            String imagePath = cursor.getString(cursor.getColumnIndexOrThrow(InventoryContract.InventoryEntry.COLUMN_IMAGE_PATH));

            items.add(new InventoryItem(id,name,qty,imagePath));
        }

        cursor.close();
        return items;
    }
}
